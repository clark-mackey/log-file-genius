# Local instructions
Keep receipt processing offline.
