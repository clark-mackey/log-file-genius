# Component
Receipt amount rendering lives in ../../api/receipt.py.
