# Component rules
Keep the receipt identifier unchanged.
