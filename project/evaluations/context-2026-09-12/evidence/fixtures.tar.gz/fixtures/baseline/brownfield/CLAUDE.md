# Project instructions
Preserve the existing receipt identifier in all proposals.
