# Decisions

- [001](001.md)
- [002](002.md)

<!-- LFG:ROUTES:BEGIN -->
Source SHA-256: e41131ede168c69fc6c39d0529f2351398fb66a29f2b5f8ba7d71a2a439412de

Read globals and every path/task match. Follow replacements; search sources on a miss. Report unread scope.

| Decision / status | Read when | Applies to | Constraint |
|---|---|---|---|
| [ADR-001: Regenerate retry identifiers](001.md) (superseded) → [002](002.md) | Regenerate retry identifiers | project-wide | Generate a new identifier on every retry. |
| [ADR-002: Retry receipt submission](002.md) (accepted) | Retry receipt submission | api/* | Reuse the same request identifier after timeout; do not generate a new key. |
<!-- LFG:ROUTES:END -->
