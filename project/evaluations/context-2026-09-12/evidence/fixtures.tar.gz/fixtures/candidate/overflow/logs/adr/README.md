# Decisions

- [001](001.md)
- [002](002.md)
- [003](003.md)
- [004](004.md)
- [005](005.md)
- [006](006.md)
- [007](007.md)
- [008](008.md)
- [009](009.md)
- [010](010.md)
- [011](011.md)
- [012](012.md)

<!-- LFG:ROUTES:BEGIN -->
Source SHA-256: 83428722e6e4eedb909a03e35656d65940b60dbcd3bc41716f256fcea6afd416

Read globals and every path/task match. Follow replacements; search sources on a miss. Report unread scope.

| Decision / status | Read when | Applies to | Constraint |
|---|---|---|---|
| [ADR-001: Preserve receipt amounts](001.md) (accepted) | Preserve receipt amounts | project-wide | Keep amounts as integer minor units; never introduce float conversion. |
| [ADR-002: Receipt component 2](002.md) (accepted) | Receipt component 2 | component2/* | Preserve receipt component 2 audit trail. |
| [ADR-003: Receipt component 3](003.md) (accepted) | Receipt component 3 | component3/* | Preserve receipt component 3 audit trail. |
| [ADR-004: Receipt component 4](004.md) (accepted) | Receipt component 4 | component4/* | Preserve receipt component 4 audit trail. |
| [ADR-005: Receipt component 5](005.md) (accepted) | Receipt component 5 | component5/* | Preserve receipt component 5 audit trail. |
| [ADR-006: Receipt component 6](006.md) (accepted) | Receipt component 6 | component6/* | Preserve receipt component 6 audit trail. |
| [ADR-007: Receipt component 7](007.md) (accepted) | Receipt component 7 | component7/* | Preserve receipt component 7 audit trail. |
| [ADR-008: Receipt component 8](008.md) (accepted) | Receipt component 8 | component8/* | Preserve receipt component 8 audit trail. |
| [ADR-009: Receipt component 9](009.md) (accepted) | Receipt component 9 | component9/* | Preserve receipt component 9 audit trail. |
| [ADR-010: Receipt component 10](010.md) (accepted) | Receipt component 10 | component10/* | Preserve receipt component 10 audit trail. |
| [ADR-011: Receipt component 11](011.md) (accepted) | Receipt component 11 | component11/* | Preserve receipt component 11 audit trail. |
| [ADR-012: Receipt component 12](012.md) (accepted) | Receipt component 12 | component12/* | Preserve receipt component 12 audit trail. |

INCOMPLETE within budget: full root including curated prose exceeds budget. Read in batches; no destinations omitted.
<!-- LFG:ROUTES:END -->
