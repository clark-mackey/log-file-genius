# Decisions

- [001](001.md)
- [002](002.md)
- [003](003.md)

<!-- LFG:ROUTES:BEGIN -->
Source SHA-256: 3397d722134c3d933a4c581433714ddc5347d0df0ab85bb669a54390be41697c

Read globals and every path/task match. Follow replacements; search sources on a miss. Report unread scope.

| Decision / status | Read when | Applies to | Constraint |
|---|---|---|---|
| [ADR-001: Preserve receipt amounts](001.md) (accepted) | Preserve receipt amounts | project-wide | Keep amounts as integer minor units; never introduce float conversion. |
| [ADR-002: Retry receipt submission](002.md) (accepted) | Retry receipt submission | api/* | Reuse the same request identifier after timeout; do not generate a new key. |
| [ADR-003: Display receipt retries](003.md) (accepted) | Display receipt retries | ui/* | Keep the failed attempt visible until the retry is acknowledged. |
<!-- LFG:ROUTES:END -->
