# Local instructions
Keep receipt processing offline.

<!-- LFG:POINTER:BEGIN -->
Read [AGENTS.md](AGENTS.md) for LFG context before task work.
<!-- LFG:POINTER:END -->
