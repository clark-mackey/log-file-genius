# Project instructions
Preserve the existing receipt identifier in all proposals.

<!-- LFG:POINTER:BEGIN -->
@AGENTS.md
<!-- LFG:POINTER:END -->
