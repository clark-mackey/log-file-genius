# Receipt desk

Small local receipt application. Run `python3 check.py` to check amount handling.

<!-- LFG:POINTER:BEGIN -->
Project context: [STATE](knowledge space/STATE.md), [decisions](knowledge space/adr/README.md).
<!-- LFG:POINTER:END -->
