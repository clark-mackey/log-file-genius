---
type: ADR Index
---

# Architectural decisions

<!-- LFG:ROUTES:BEGIN -->
Source SHA-256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855

Read globals and every path/task match. Follow replacements; search sources on a miss. Report unread scope.

| Decision / status | Read when | Applies to | Constraint |
|---|---|---|---|
<!-- LFG:ROUTES:END -->
